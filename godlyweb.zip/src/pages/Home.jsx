import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Zap, 
  DollarSign, 
  Clock, 
  Smartphone, 
  TrendingUp, 
  Shield,
  ArrowRight,
  Sparkles
} from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  useEffect(() => {
    // Set SEO meta tags
    document.title = "GodlyWeb - Modern, Affordable Website Design for Small Businesses";
    
    // Meta description
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute("content", "Get a stunning, professional website in days—not weeks. GodlyWeb offers fast, affordable web design for small businesses, creators, and entrepreneurs. No hidden fees, mobile-optimized, SEO-ready.");
    } else {
      const meta = document.createElement('meta');
      meta.name = "description";
      meta.content = "Get a stunning, professional website in days—not weeks. GodlyWeb offers fast, affordable web design for small businesses, creators, and entrepreneurs. No hidden fees, mobile-optimized, SEO-ready.";
      document.head.appendChild(meta);
    }

    // Meta keywords
    const metaKeywords = document.querySelector('meta[name="keywords"]');
    const keywordsContent = "website design, affordable web design, small business website, website builder, professional website, fast website delivery, mobile optimized, SEO website";
    if (metaKeywords) {
      metaKeywords.setAttribute("content", keywordsContent);
    } else {
      const meta = document.createElement('meta');
      meta.name = "keywords";
      meta.content = keywordsContent;
      document.head.appendChild(meta);
    }

    // Open Graph tags
    let ogTitle = document.querySelector('meta[property="og:title"]');
    if (ogTitle) {
      ogTitle.setAttribute("content", "GodlyWeb - Modern, Affordable Website Design");
    } else {
      ogTitle = document.createElement('meta');
      ogTitle.setAttribute("property", "og:title");
      ogTitle.content = "GodlyWeb - Modern, Affordable Website Design";
      document.head.appendChild(ogTitle);
    }

    let ogDescription = document.querySelector('meta[property="og:description"]');
    if (ogDescription) {
      ogDescription.setAttribute("content", "Professional websites delivered in days. Perfect for small businesses, creators, and entrepreneurs.");
    } else {
      ogDescription = document.createElement('meta');
      ogDescription.setAttribute("property", "og:description");
      ogDescription.content = "Professional websites delivered in days. Perfect for small businesses, creators, and entrepreneurs.";
      document.head.appendChild(ogDescription);
    }
  }, []);

  const features = [
    {
      icon: Zap,
      title: "Lightning Fast",
      description: "Get your website live in days, not weeks or months"
    },
    {
      icon: DollarSign,
      title: "Affordable Pricing",
      description: "Premium quality without the premium price tag"
    },
    {
      icon: Smartphone,
      title: "Mobile Optimized",
      description: "Perfect on every device, from phones to desktops"
    },
    {
      icon: TrendingUp,
      title: "Built to Convert",
      description: "Designed to turn visitors into loyal customers"
    },
    {
      icon: Clock,
      title: "Quick Turnaround",
      description: "Fast delivery without compromising on quality"
    },
    {
      icon: Shield,
      title: "Zero Hidden Fees",
      description: "Clear pricing and honest communication always"
    }
  ];

  return (
    <div className="w-full">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-purple-50 via-white to-cyan-50">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(147,51,234,0.1),transparent_50%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_80%,rgba(6,182,212,0.1),transparent_50%)]" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-purple-100 rounded-full mb-8">
              <Sparkles className="w-4 h-4 text-purple-600" />
              <span className="text-sm font-medium text-purple-600">
                Professional Websites, Godly Results
              </span>
            </div>

            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-gray-900 mb-6 leading-tight">
              <span className="bg-gradient-to-r from-purple-600 to-cyan-500 bg-clip-text text-transparent">
                Launch Faster.
                <br />
                Grow Bigger.
              </span>
            </h1>

            <p className="text-xl text-gray-600 mb-12 max-w-3xl mx-auto leading-relaxed">
              Modern, affordable web design for small businesses and creators.
              Get a stunning, high-converting website in days—not weeks—with zero hidden fees.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to={createPageUrl("Contact")}
                className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-gradient-to-r from-purple-600 to-cyan-500 text-white rounded-full font-semibold text-lg hover:shadow-2xl hover:scale-105 transition-all duration-300"
              >
                Start Your Project
                <ArrowRight className="w-5 h-5" />
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">
              Why Choose GodlyWeb?
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              We combine speed, quality, and affordability to deliver exceptional results
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="p-8 bg-gradient-to-br from-purple-50 to-cyan-50 rounded-2xl hover:shadow-xl transition-all duration-300 group"
              >
                <div className="w-14 h-14 bg-gradient-to-br from-purple-600 to-cyan-500 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                  <feature.icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">
                  {feature.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {feature.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-purple-600 via-purple-700 to-cyan-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl sm:text-5xl font-bold text-white mb-6">
              Ready to Go Live?
            </h2>
            <p className="text-xl text-purple-100 mb-10 leading-relaxed">
              Join hundreds of businesses that chose GodlyWeb for their online presence.
              Let's create something amazing together.
            </p>
            <Link
              to={createPageUrl("Contact")}
              className="inline-flex items-center gap-2 px-10 py-4 bg-white text-purple-600 rounded-full font-bold text-lg hover:shadow-2xl hover:scale-105 transition-all duration-300"
            >
              Start Your Project Today
              <ArrowRight className="w-5 h-5" />
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
}