import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { motion } from "framer-motion";
import { 
  User, 
  Mail, 
  LogOut, 
  Save,
  Shield,
  Calendar
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { format } from "date-fns";

export default function Profile() {
  const [user, setUser] = useState(null);
  const [fullName, setFullName] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [message, setMessage] = useState(null);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
      setFullName(currentUser.full_name || "");
      setIsLoading(false);
    } catch (err) {
      base44.auth.redirectToLogin();
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    setMessage(null);
    try {
      await base44.auth.updateMe({ full_name: fullName });
      setMessage({ type: "success", text: "Profile updated successfully!" });
      await loadUser();
    } catch (err) {
      setMessage({ type: "error", text: "Failed to update profile" });
    } finally {
      setIsSaving(false);
    }
  };

  const handleSignOut = () => {
    base44.auth.logout();
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-purple-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-gradient-to-br from-purple-600 to-cyan-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <User className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-4xl font-bold text-gray-900 mb-2">
              My Profile
            </h1>
            <p className="text-gray-600">
              Manage your account settings
            </p>
          </div>

          <div className="grid gap-6">
            {/* Account Info Card */}
            <div className="bg-white rounded-2xl shadow-lg p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">
                Account Information
              </h2>
              
              <div className="space-y-6">
                {/* Email (read-only) */}
                <div className="space-y-2">
                  <Label className="text-gray-700 font-medium">
                    Email Address
                  </Label>
                  <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
                    <Mail className="w-5 h-5 text-gray-400" />
                    <span className="text-gray-600">{user?.email}</span>
                  </div>
                </div>

                {/* Full Name */}
                <div className="space-y-2">
                  <Label htmlFor="fullName" className="text-gray-700 font-medium">
                    Full Name
                  </Label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <Input
                      id="fullName"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      className="pl-11 h-12 border-gray-200 focus:border-purple-500"
                      placeholder="Enter your full name"
                    />
                  </div>
                </div>

                {/* Role Badge */}
                <div className="space-y-2">
                  <Label className="text-gray-700 font-medium">
                    Account Role
                  </Label>
                  <div className="flex items-center gap-3">
                    <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full ${
                      user?.role === 'admin' 
                        ? 'bg-purple-100 text-purple-700' 
                        : 'bg-gray-100 text-gray-700'
                    }`}>
                      <Shield className="w-4 h-4" />
                      <span className="font-medium capitalize">{user?.role}</span>
                    </div>
                  </div>
                </div>

                {/* Created Date */}
                <div className="space-y-2">
                  <Label className="text-gray-700 font-medium">
                    Member Since
                  </Label>
                  <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
                    <Calendar className="w-5 h-5 text-gray-400" />
                    <span className="text-gray-600">
                      {format(new Date(user?.created_date), 'PPP')}
                    </span>
                  </div>
                </div>

                {message && (
                  <Alert variant={message.type === "error" ? "destructive" : "default"}>
                    <AlertDescription>{message.text}</AlertDescription>
                  </Alert>
                )}

                <Button
                  onClick={handleSave}
                  disabled={isSaving}
                  className="w-full h-12 bg-gradient-to-r from-purple-600 to-cyan-500 hover:shadow-lg text-base font-semibold"
                >
                  {isSaving ? (
                    <span className="flex items-center gap-2">
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      Saving...
                    </span>
                  ) : (
                    <span className="flex items-center gap-2">
                      <Save className="w-5 h-5" />
                      Save Changes
                    </span>
                  )}
                </Button>
              </div>
            </div>

            {/* Sign Out Card */}
            <div className="bg-white rounded-2xl shadow-lg p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">
                Account Actions
              </h2>
              <p className="text-gray-600 mb-6">
                Sign out of your account on this device
              </p>
              <Button
                onClick={handleSignOut}
                variant="outline"
                className="w-full h-12 border-2 border-red-200 text-red-600 hover:bg-red-50 hover:border-red-300 text-base font-semibold"
              >
                <LogOut className="w-5 h-5 mr-2" />
                Sign Out
              </Button>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}