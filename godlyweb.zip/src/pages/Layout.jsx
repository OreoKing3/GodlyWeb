
import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Sparkles, Mail, Phone, Shield, User } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
  const [user, setUser] = React.useState(null);

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      } catch (err) {
        setUser(null);
      }
    };
    loadUser();
  }, []);

  const navItems = [
    { name: "Home", path: createPageUrl("Home") },
    { name: "Contact", path: createPageUrl("Contact") },
  ];

  const isActive = (path) => location.pathname === path;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50 to-cyan-50">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-purple-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            {/* Logo */}
            <Link to={createPageUrl("Home")} className="flex items-center gap-2 group">
              <div className="w-10 h-10 bg-gradient-to-br from-purple-600 to-cyan-500 rounded-lg flex items-center justify-center shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-105">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-cyan-500 bg-clip-text text-transparent">
                GodlyWeb
              </span>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-8">
              {navItems.map((item) => (
                <Link
                  key={item.name}
                  to={item.path}
                  className={`text-sm font-medium transition-all duration-300 ${
                    isActive(item.path)
                      ? "text-purple-600"
                      : "text-gray-600 hover:text-purple-600"
                  }`}
                >
                  {item.name}
                </Link>
              ))}
              {user?.role === "admin" && (
                <Link
                  to={createPageUrl("AdminSubmissions")}
                  className={`flex items-center gap-1 text-sm font-medium transition-all duration-300 ${
                    isActive(createPageUrl("AdminSubmissions"))
                      ? "text-purple-600"
                      : "text-gray-600 hover:text-purple-600"
                  }`}
                >
                  <Shield className="w-4 h-4" />
                  Admin
                </Link>
              )}
              {user ? (
                <Link
                  to={createPageUrl("Profile")}
                  className={`flex items-center gap-1 text-sm font-medium transition-all duration-300 ${
                    isActive(createPageUrl("Profile"))
                      ? "text-purple-600"
                      : "text-gray-600 hover:text-purple-600"
                  }`}
                >
                  <User className="w-4 h-4" />
                  Profile
                </Link>
              ) : (
                <button
                  onClick={() => base44.auth.redirectToLogin()}
                  className="text-sm font-medium text-gray-600 hover:text-purple-600 transition-all duration-300"
                >
                  Sign In
                </button>
              )}
              <Link
                to={createPageUrl("GetStarted")}
                className="px-6 py-2.5 bg-gradient-to-r from-purple-600 to-cyan-500 text-white rounded-full font-medium hover:shadow-lg hover:scale-105 transition-all duration-300"
              >
                Get Started
              </Link>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-lg hover:bg-purple-50 transition-colors"
            >
              <div className="w-6 h-5 flex flex-col justify-between">
                <span className={`w-full h-0.5 bg-purple-600 transition-all ${mobileMenuOpen ? 'rotate-45 translate-y-2' : ''}`} />
                <span className={`w-full h-0.5 bg-purple-600 transition-all ${mobileMenuOpen ? 'opacity-0' : ''}`} />
                <span className={`w-full h-0.5 bg-purple-600 transition-all ${mobileMenuOpen ? '-rotate-45 -translate-y-2' : ''}`} />
              </div>
            </button>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden py-4 border-t border-purple-100">
              {navItems.map((item) => (
                <Link
                  key={item.name}
                  to={item.path}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`block py-3 px-4 rounded-lg transition-colors ${
                    isActive(item.path)
                      ? "bg-purple-50 text-purple-600 font-medium"
                      : "text-gray-600 hover:bg-purple-50"
                  }`}
                >
                  {item.name}
                </Link>
              ))}
              {user?.role === "admin" && (
                <Link
                  to={createPageUrl("AdminSubmissions")}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`flex items-center gap-2 py-3 px-4 rounded-lg transition-colors ${
                    isActive(createPageUrl("AdminSubmissions"))
                      ? "bg-purple-50 text-purple-600 font-medium"
                      : "text-gray-600 hover:bg-purple-50"
                  }`}
                >
                  <Shield className="w-4 h-4" />
                  Admin
                </Link>
              )}
              {user ? (
                <Link
                  to={createPageUrl("Profile")}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`flex items-center gap-2 py-3 px-4 rounded-lg transition-colors ${
                    isActive(createPageUrl("Profile"))
                      ? "bg-purple-50 text-purple-600 font-medium"
                      : "text-gray-600 hover:bg-purple-50"
                  }`}
                >
                  <User className="w-4 h-4" />
                  Profile
                </Link>
              ) : (
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    base44.auth.redirectToLogin();
                  }}
                  className="w-full text-left py-3 px-4 text-gray-600 hover:bg-purple-50 rounded-lg transition-colors"
                >
                  Sign In
                </button>
              )}
              <Link
                to={createPageUrl("GetStarted")}
                onClick={() => setMobileMenuOpen(false)}
                className="block mt-2 py-3 px-4 bg-gradient-to-r from-purple-600 to-cyan-500 text-white text-center rounded-lg font-medium"
              >
                Get Started
              </Link>
            </div>
          )}
        </div>
      </nav>

      {/* Main Content */}
      <main className="pt-20">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-gradient-to-br from-purple-900 via-purple-800 to-cyan-900 text-white mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Brand */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 bg-white/10 backdrop-blur-sm rounded-lg flex items-center justify-center">
                  <Sparkles className="w-6 h-6 text-cyan-300" />
                </div>
                <span className="text-2xl font-bold">GodlyWeb</span>
              </div>
              <p className="text-purple-200 text-sm leading-relaxed">
                Modern, affordable website-building service for small businesses and creators.
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h3 className="font-semibold text-lg mb-4">Quick Links</h3>
              <div className="space-y-2">
                {navItems.map((item) => (
                  <Link
                    key={item.name}
                    to={item.path}
                    className="block text-purple-200 hover:text-white transition-colors text-sm"
                  >
                    {item.name}
                  </Link>
                ))}
              </div>
            </div>

            {/* Contact Info */}
            <div>
              <h3 className="font-semibold text-lg mb-4">Get in Touch</h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3 text-purple-200 text-sm">
                  <Mail className="w-4 h-4" />
                  <span>thegodlyweb@gmail.com</span>
                </div>
                <div className="flex items-center gap-3 text-purple-200 text-sm">
                  <Phone className="w-4 h-4" />
                  <span>+1 (703) 967-4758</span>
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-white/10 mt-8 pt-8 text-center text-purple-200 text-sm">
            <p>© 2024 GodlyWeb. All rights reserved. Built with passion for small businesses.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
