import React from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { motion } from "framer-motion";
import { 
  Mail, 
  Phone, 
  Building2, 
  Package, 
  Clock,
  DollarSign,
  MessageSquare,
  CheckCircle2,
  XCircle,
  Calendar
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { format } from "date-fns";

export default function AdminSubmissions() {
  const queryClient = useQueryClient();

  const { data: submissions = [], isLoading } = useQuery({
    queryKey: ['contactSubmissions'],
    queryFn: () => base44.entities.ContactSubmission.list('-created_date'),
  });

  const updateStatusMutation = useMutation({
    mutationFn: ({ id, status }) => 
      base44.entities.ContactSubmission.update(id, { status }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['contactSubmissions'] });
    },
  });

  const statusColors = {
    new: "bg-blue-100 text-blue-800",
    contacted: "bg-yellow-100 text-yellow-800",
    closed: "bg-green-100 text-green-800"
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-purple-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50 to-cyan-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            Contact Submissions
          </h1>
          <p className="text-gray-600">
            Manage and track all website inquiries
          </p>
        </div>

        <div className="grid gap-6">
          {submissions.length === 0 ? (
            <div className="bg-white rounded-2xl p-12 text-center">
              <p className="text-gray-500">No submissions yet</p>
            </div>
          ) : (
            submissions.map((submission, index) => (
              <motion.div
                key={submission.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
                className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-shadow"
              >
                <div className="flex flex-col lg:flex-row gap-6">
                  <div className="flex-1 space-y-4">
                    {/* Header */}
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <h3 className="text-2xl font-bold text-gray-900 mb-1">
                          {submission.name}
                        </h3>
                        <div className="flex items-center gap-2 text-sm text-gray-500">
                          <Calendar className="w-4 h-4" />
                          {format(new Date(submission.created_date), 'PPP p')}
                        </div>
                      </div>
                      <Select
                        value={submission.status}
                        onValueChange={(status) => 
                          updateStatusMutation.mutate({ id: submission.id, status })
                        }
                      >
                        <SelectTrigger className="w-36">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="new">New</SelectItem>
                          <SelectItem value="contacted">Contacted</SelectItem>
                          <SelectItem value="closed">Closed</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Contact Info */}
                    <div className="grid sm:grid-cols-2 gap-3">
                      <div className="flex items-center gap-2 text-gray-700">
                        <Mail className="w-4 h-4 text-purple-600" />
                        <a href={`mailto:${submission.email}`} className="hover:underline">
                          {submission.email}
                        </a>
                      </div>
                      {submission.phone && (
                        <div className="flex items-center gap-2 text-gray-700">
                          <Phone className="w-4 h-4 text-purple-600" />
                          <a href={`tel:${submission.phone}`} className="hover:underline">
                            {submission.phone}
                          </a>
                        </div>
                      )}
                      {submission.businessName && (
                        <div className="flex items-center gap-2 text-gray-700">
                          <Building2 className="w-4 h-4 text-purple-600" />
                          {submission.businessName}
                        </div>
                      )}
                    </div>

                    {/* Project Details */}
                    <div className="flex flex-wrap gap-2">
                      <Badge className={statusColors[submission.status]}>
                        {submission.status}
                      </Badge>
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Package className="w-3 h-3" />
                        {submission.serviceType}
                      </Badge>
                      {submission.budget && (
                        <Badge variant="outline" className="flex items-center gap-1">
                          <DollarSign className="w-3 h-3" />
                          {submission.budget}
                        </Badge>
                      )}
                      {submission.timeline && (
                        <Badge variant="outline" className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {submission.timeline}
                        </Badge>
                      )}
                    </div>

                    {/* Message */}
                    <div className="bg-gray-50 rounded-xl p-4">
                      <div className="flex items-start gap-2 mb-2">
                        <MessageSquare className="w-4 h-4 text-gray-500 mt-0.5" />
                        <span className="text-sm font-medium text-gray-700">Message:</span>
                      </div>
                      <p className="text-gray-600 leading-relaxed">
                        {submission.message}
                      </p>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}