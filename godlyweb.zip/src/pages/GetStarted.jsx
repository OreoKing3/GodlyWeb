import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";
import { 
  CheckCircle2, 
  ArrowRight, 
  Clock,
  FileText,
  MessageSquare,
  Zap,
  Sparkles
} from "lucide-react";

export default function GetStarted() {
  useEffect(() => {
    document.title = "Get Started with GodlyWeb - Launch Your Website in 3 Easy Steps";
    
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute("content", "Start your website journey with GodlyWeb today. Simple 3-step process to get your professional website live in days. No technical skills needed.");
    } else {
      const meta = document.createElement('meta');
      meta.name = "description";
      meta.content = "Start your website journey with GodlyWeb today. Simple 3-step process to get your professional website live in days. No technical skills needed.";
      document.head.appendChild(meta);
    }
  }, []);

  const steps = [
    {
      number: "01",
      title: "Share Your Vision",
      description: "Tell us about your business, goals, and what you want your website to achieve. The more details you share, the better we can bring your vision to life.",
      icon: MessageSquare,
      color: "from-blue-500 to-cyan-500"
    },
    {
      number: "02",
      title: "We Design & Build",
      description: "Our team creates a stunning, professional website tailored to your brand. You'll receive drafts for review and can request revisions until it's perfect.",
      icon: Sparkles,
      color: "from-purple-500 to-pink-500"
    },
    {
      number: "03",
      title: "Launch & Grow",
      description: "Your website goes live! We handle all the technical details and provide 30 days of free maintenance. Then watch your business grow online.",
      icon: Zap,
      color: "from-orange-500 to-red-500"
    }
  ];

  const benefits = [
    "No technical knowledge required",
    "Fast delivery - websites ready in days",
    "Mobile-responsive design included",
    "SEO optimization for better visibility",
    "Free revisions until you're satisfied",
    "30 days of free post-launch support",
    "Clear, transparent pricing",
    "Dedicated project manager"
  ];

  const faqs = [
    {
      question: "How long does it take?",
      answer: "Most projects are completed within 3-7 days, depending on complexity and your responsiveness with feedback."
    },
    {
      question: "What do I need to provide?",
      answer: "Just your business information, any existing branding materials (logo, colors), content you want on the site, and any specific features you need."
    },
    {
      question: "Can I make changes after launch?",
      answer: "Absolutely! You get 30 days of free maintenance. After that, we offer affordable maintenance plans or one-time update services."
    },
    {
      question: "What if I don't like the design?",
      answer: "We include unlimited revisions in all our packages. We'll work with you until you're completely satisfied with the result."
    }
  ];

  return (
    <div className="w-full">
      {/* Hero Section */}
      <section className="relative min-h-[70vh] flex items-center justify-center overflow-hidden bg-gradient-to-br from-purple-50 via-white to-cyan-50">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(147,51,234,0.15),transparent_50%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_80%,rgba(6,182,212,0.15),transparent_50%)]" />
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-purple-100 rounded-full mb-8">
              <Sparkles className="w-4 h-4 text-purple-600" />
              <span className="text-sm font-medium text-purple-600">
                Your Website Journey Starts Here
              </span>
            </div>

            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-gray-900 mb-6 leading-tight">
              Launch Your Website in
              <br />
              <span className="bg-gradient-to-r from-purple-600 to-cyan-500 bg-clip-text text-transparent">
                3 Simple Steps
              </span>
            </h1>

            <p className="text-xl text-gray-600 mb-12 max-w-3xl mx-auto leading-relaxed">
              No coding. No hassle. Just a beautiful, professional website that helps your business grow.
            </p>

            <Link
              to={createPageUrl("Contact")}
              className="inline-flex items-center justify-center gap-2 px-10 py-4 bg-gradient-to-r from-purple-600 to-cyan-500 text-white rounded-full font-semibold text-lg hover:shadow-2xl hover:scale-105 transition-all duration-300"
            >
              Start Your Project
              <ArrowRight className="w-5 h-5" />
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Steps Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">
              How It Works
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              From idea to launch, we make the process smooth and straightforward
            </p>
          </div>

          <div className="space-y-12">
            {steps.map((step, index) => (
              <motion.div
                key={step.number}
                initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                viewport={{ once: true }}
                className={`flex flex-col ${index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'} items-center gap-12`}
              >
                <div className="flex-1">
                  <div className="flex items-center gap-4 mb-4">
                    <div className={`w-16 h-16 bg-gradient-to-br ${step.color} rounded-2xl flex items-center justify-center shadow-lg`}>
                      <step.icon className="w-8 h-8 text-white" />
                    </div>
                    <span className="text-5xl font-bold text-gray-200">{step.number}</span>
                  </div>
                  <h3 className="text-3xl font-bold text-gray-900 mb-4">
                    {step.title}
                  </h3>
                  <p className="text-lg text-gray-600 leading-relaxed">
                    {step.description}
                  </p>
                </div>

                <div className={`flex-1 w-full h-80 bg-gradient-to-br ${step.color} rounded-3xl shadow-2xl`}>
                  {/* Placeholder for illustration */}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-gradient-to-br from-purple-50 via-white to-cyan-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">
              What You Get
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Everything you need for a successful online presence
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {benefits.map((benefit, index) => (
              <motion.div
                key={benefit}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="flex items-start gap-3 p-6 bg-white rounded-2xl shadow-md hover:shadow-xl transition-shadow"
              >
                <CheckCircle2 className="w-6 h-6 text-green-500 flex-shrink-0 mt-0.5" />
                <span className="text-gray-700 font-medium">{benefit}</span>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">
              Common Questions
            </h2>
            <p className="text-xl text-gray-600">
              Everything you need to know about getting started
            </p>
          </div>

          <div className="space-y-6">
            {faqs.map((faq, index) => (
              <motion.div
                key={faq.question}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="p-8 bg-gradient-to-br from-purple-50 to-cyan-50 rounded-2xl"
              >
                <h3 className="text-xl font-bold text-gray-900 mb-3">
                  {faq.question}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {faq.answer}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 bg-gradient-to-br from-purple-600 via-purple-700 to-cyan-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl sm:text-5xl font-bold text-white mb-6">
              Ready to Get Started?
            </h2>
            <p className="text-xl text-purple-100 mb-10 leading-relaxed">
              Let's create something amazing together. Fill out our quick form and we'll be in touch within 24 hours.
            </p>
            <Link
              to={createPageUrl("Contact")}
              className="inline-flex items-center gap-2 px-10 py-4 bg-white text-purple-600 rounded-full font-bold text-lg hover:shadow-2xl hover:scale-105 transition-all duration-300"
            >
              Start Your Project Now
              <ArrowRight className="w-5 h-5" />
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
}